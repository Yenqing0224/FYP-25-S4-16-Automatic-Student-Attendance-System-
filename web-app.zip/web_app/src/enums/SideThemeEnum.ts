export enum SideThemeEnum {
  DARK = 'theme-dark',
  LIGHT = 'theme-light'
}
