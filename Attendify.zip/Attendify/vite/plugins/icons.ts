import Icons from 'unplugin-icons/vite';

export default () => {
  return Icons({
    // 自动安装图标库
    autoInstall: true
  });
};
