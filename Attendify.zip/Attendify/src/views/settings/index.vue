<template>
  <div class="p-4">
    <el-card shadow="hover">
      <template #header>
        <span>Settings</span>
      </template>
      <p class="text-gray-500">This page is reserved for future settings configuration.</p>
    </el-card>
  </div>
</template>

<script setup lang="ts">
defineOptions({ name: 'SettingsPage' });
</script>

