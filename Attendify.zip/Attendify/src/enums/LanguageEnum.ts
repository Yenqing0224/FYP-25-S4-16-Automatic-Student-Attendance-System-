export enum LanguageEnum {
  zh_CN = 'zh_CN',

  en_US = 'en_US'
}
