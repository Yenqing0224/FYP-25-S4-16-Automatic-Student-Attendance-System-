export enum MenuTypeEnum {
  /**
   * 目录
   */
  M = 'M',
  /**
   * 菜单
   */
  C = 'C',

  /**
   * 按钮
   */
  F = 'F'
}
