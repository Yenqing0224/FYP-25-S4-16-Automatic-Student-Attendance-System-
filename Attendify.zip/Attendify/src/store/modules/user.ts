import { getToken, removeToken, setToken } from '@/utils/auth';
import { LoginData } from '@/api/types';
import defAva from '@/assets/images/profile.jpg';
import { defineStore } from 'pinia';
import { ref } from 'vue';

export const useUserStore = defineStore('user', () => {
  const token = ref(getToken());
  const name = ref('');
  const nickname = ref('');
  const userId = ref<string | number>('');
  const tenantId = ref<string>('');
  const avatar = ref('');
  const roles = ref<Array<string>>([]); // 用户角色编码集合 → 判断路由权限
  const permissions = ref<Array<string>>([]); // 用户权限编码集合 → 判断按钮权限

  /**
   * 登录 - 使用Mock数据
   * @param userInfo
   * @returns
   */
  const login = async (userInfo: LoginData): Promise<void> => {
    // Mock login - 验证账号密码
    if (userInfo.username === 'admin' && userInfo.password === 'admin1') {
      // 模拟API延迟
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Mock token
      const mockToken = 'mock_token_' + Date.now();
      setToken(mockToken);
      token.value = mockToken;
      return Promise.resolve();
    } else {
      // 登录失败
      const error = new Error('Invalid username or password');
      return Promise.reject(error);
    }
  };

  // 获取用户信息 - 使用Mock数据
  const getInfo = async (): Promise<void> => {
    // 模拟API延迟
    await new Promise((resolve) => setTimeout(resolve, 300));

    // Mock user data
    const mockUser = {
      user: {
        userId: '1',
        userName: 'admin',
        nickName: 'Administrator',
        avatar: '',
        tenantId: '000000'
      },
      roles: ['admin', 'ROLE_DEFAULT'],
      permissions: ['*:*:*']
    };

    const user = mockUser.user;
      const profile = user.avatar == '' || user.avatar == null ? defAva : user.avatar;

    if (mockUser.roles && mockUser.roles.length > 0) {
      roles.value = mockUser.roles;
      permissions.value = mockUser.permissions;
      } else {
        roles.value = ['ROLE_DEFAULT'];
      }
      name.value = user.userName;
      nickname.value = user.nickName;
      avatar.value = profile;
      userId.value = user.userId;
      tenantId.value = user.tenantId;
      return Promise.resolve();
  };

  // 注销 - 使用Mock数据
  const logout = async (): Promise<void> => {
    // Mock logout - 不需要调用API
    token.value = '';
    roles.value = [];
    permissions.value = [];
    removeToken();
    return Promise.resolve();
  };

  const setAvatar = (value: string) => {
    avatar.value = value;
  };

  return {
    userId,
    tenantId,
    token,
    nickname,
    avatar,
    roles,
    permissions,
    login,
    getInfo,
    logout,
    setAvatar
  };
});
